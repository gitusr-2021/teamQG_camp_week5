/***************************************************************************************
 *	File Name				:
 *	CopyRight				:
 *	ModuleName				:
 *
 *	CPU						:
 *	RTOS					:
 *
 *	Create Date				:2021/4/21
 *	Author/Corportation		:eke_l
 *
 *	Abstract Description	:����������ͷ�ļ�
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Date			Revised By			Item			Description
 *
 *
 ***************************************************************************************/


/**************************************************************
*	Multi-Include-Prevent Section
**************************************************************/
#ifndef BINARYSORTTREE_BINARY_SORT_TREE_H
#define BINARYSORTTREE_BINARY_SORT_TREE_H

/**************************************************************
*	Macro Define Section
**************************************************************/
#define true 1
#define false 0
#define succeed 1
#define failed 0
#define BSTStatus int

/**************************************************************
*	Enum Define Section
**************************************************************/
typedef enum Status
{
    ERROR = 0,
	SUCCESS = 1
} Status;

/**************************************************************
*	Typedef Define Section
**************************************************************/
typedef int ElemType;

/**************************************************************
*	Struct Define Section
**************************************************************/
typedef struct Node{
    ElemType value;
    struct Node *left, *right;
}Node, *NodePtr;

typedef struct BinarySortTree{
    NodePtr root;
} BinarySortTree, *BinarySortTreePtr;

/**************************************************************
*	Prototype Declare Section
**************************************************************/
//****�˵������뺯��****
/**
 * BST �˵�
 * @param none
 * @return none
 */
void Menu();

/**
 *@name			:optionInput(char *option)
 *@description	:����ѡ�����룬�����ַ����������飬����һ���ַ�
����Ĵӻ���������
 *@param		:option
 *@return		:none
 *@notice		:none
*/
void optionInput(char *option);

/**
 *  @name        : ElemTypeInput
 *	@description : ����Ƿ��з��������벢���������봫��ָ����ָ�ı���
 *	@param		 : p
 *	@return		 : none
 *  @notice      : None
*/
void ElemTypeInput(ElemType *p);

//****����������****
/**
 * BST creatNode
 * @param none
 * @return NodePtr,һ��û�г�ʼ��value�Ľڵ�
 */
NodePtr creatNode();

/**
 * BST initialize
 * @param BinarySortTreePtr BST
 * @return is complete
 */
BSTStatus BST_init(BinarySortTreePtr);

/**
 * BST insert
 * @param BinarySortTreePtr BST
 * @param ElemType value to insert
 * @return is successful
 */
BSTStatus BST_insert(BinarySortTreePtr, ElemType);

/**
 * BST delete
 * @param BinarySortTreePtr BST
 * @param ElemType the value for Node which will be deleted
 * @return is successful
 */
BSTStatus BST_delete(BinarySortTreePtr, ElemType);

/**
 * BST search
 * @param BinarySortTreePtr BST
 * @param ElemType the value to search
 * @return is exist
 */
BSTStatus BST_search(BinarySortTreePtr, ElemType);

//ע�����Ⱥ��ʦ�����ԣ��ݹ���������޸����β��Է���ݹ�
/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BSTStatus BST_preorderI(BinarySortTreePtr, void (*visit)(NodePtr));

/**
 * BST preorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BSTStatus BST_preorderR(NodePtr, void (*visit)(NodePtr));

/**
 * BST inorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BSTStatus BST_inorderI(BinarySortTreePtr, void (*visit)(NodePtr));

/**
 * BST inorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BSTStatus BST_inorderR(NodePtr, void (*visit)(NodePtr));

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BSTStatus BST_postorderI(BinarySortTreePtr, void (*visit)(NodePtr));

/**
 * BST postorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BSTStatus BST_postorderR(NodePtr, void (*visit)(NodePtr));

/**
 * BST level order traversal
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BSTStatus BST_levelOrder(BinarySortTreePtr, void (*visit)(NodePtr));

//****��ӡ����****
/**
 * printValue
 * @param NodePtr asisNodePtr BST
 * @funcion ��ӡ�ڵ��ֵ
 * @return none
 */
void printValue(NodePtr asisNodePtr);

/**************************************************************
*	End-Multi-Include-Prevent Section
**************************************************************/
#endif //BINARYSORTTREE_BINARY_SORT_TREE_H
