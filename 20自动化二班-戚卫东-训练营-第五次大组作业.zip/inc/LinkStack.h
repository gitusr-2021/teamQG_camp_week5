/***************************************************************************************
 *	File Name				:LinkStack
 *	CopyRight				:
 *	ModuleName				:
 *
 *	CPU			:
 *	RTOS			:
 *
 *	Create Data		:
 *	Author/Corportation	:QiWeidong
 *
 *	Abstract Description	:	this will be used for QG�ڶ��ܴ�������
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Date			Revised By			Item			Description
 *	1.0				2021��4��4��	QiWeidong							������ⲿ��
 *
 ***************************************************************************************/

/**************************************************************
*	Multi-Include-Prevent Section
**************************************************************/
#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

/**************************************************************
*	Include File Section
**************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "binary_sort_tree.h"
#include "LinkStack.h"
#include "LQueue.h"

/**************************************************************
*	Type Define Section
**************************************************************/
typedef int ElemType;

/**************************************************************
*	Struct Define Section
**************************************************************/
typedef  struct StackNode
{
	NodePtr treeNodePtr;
	struct StackNode *next;
}StackNode, *LinkStackPtr;

typedef  struct  LinkStack
{
	LinkStackPtr top;
	int	count;
}LinkStack;


/**************************************************************
*	Prototype Declare Section
**************************************************************/
//��ջ

/**
 *@name			:initLStack(LinkStack *s)
 *@description	:��ʼ��ջ
 *@param		:*s
 *@return		:Status
 *@notice		:none
*/
Status initLStack(LinkStack *s);

/**
 *@name			:isEmptyLStack(LinkStack *s)
 *@description	:�ж�ջ�Ƿ�Ϊ��
 *@param		:*s(ջ�ṹ���ָ��)
 *@return		:Status
 *@notice		:none
*/
Status isEmptyLStack(LinkStack *s);

/**
 *@name			:pushLStack(LinkStack *s,ElemType data)
 *@description	:��ջ
 *@param		:*s(ջ�ṹ��ָ��),NodePtr treeNode
 *@return		:Status
 *@notice		:none
*/
Status pushLStack(LinkStack *s,NodePtr treeNodePtr);

/**
 *@name			:popLStack(LinkStack *s,ElemType *data)
 *@description	:���ջ�����ݲ�����ջ��
 *@param		:*s(ջ�ṹ��ָ��),NodePtr treeNode(���������)
 *@return		:Status
 *@notice		:none
*/
Status popLStack(LinkStack *s,NodePtr *treeNodePtr);


/**
 *@name			:destroyLStack(LinkStack *s)
 *@description	:����ջ
 *@param		:*s(ջ�ṹ��ָ��)
 *@return		:Status
 *@notice		:none
*/
Status destroyLStack(LinkStack *s);//����ջ

/**************************************************************
*	End-Multi-Include-Prevent Section
**************************************************************/
#endif
